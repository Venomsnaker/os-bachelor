struct sysinfo {
  int freemem;   // amount of free memory (bytes)
  int nproc;     // number of process
};
